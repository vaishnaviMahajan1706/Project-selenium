package Utils;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

public class ScreenshotUtil {

    public static String captureScreenshot(WebDriver driver, String screenshotName) {
        TakesScreenshot ts = (TakesScreenshot) driver;
        File src = ts.getScreenshotAs(OutputType.FILE);

        String folderPath = System.getProperty("user.dir") + "/test-output/screenshots/";
        File folder = new File(folderPath);
        if (!folder.exists()) folder.mkdirs();

        String dest = folderPath + screenshotName + ".png";
        try {
            Files.copy(src.toPath(), new File(dest).toPath());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return dest;
    }
}
