package Utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

public class BaseTestWithReport {
    public ExtentReports extent;
    public ExtentTest test;

    @BeforeClass
    public void setupReport() {
        extent = ExtentManager.getInstance();
    }

    @AfterClass
    public void teardownReport() {
        extent.flush(); // write results
    }
}
