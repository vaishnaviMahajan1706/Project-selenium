package Tests;

import Pages.*;
import Utils.DriverManager;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;

public class PurchaseFlowTest {

    WebDriver driver;
    LoginPage loginPage;
    ProductPage productsPage;
    Cartpage cartPage;
    ChechoutPage checkoutPage;

    @BeforeMethod
    public void setup() {
        driver = DriverManager.getDriver();
        driver.get("https://www.saucedemo.com/");
        loginPage = new LoginPage(driver);
        productsPage = new ProductPage(driver);
        cartPage = new Cartpage(driver);
        checkoutPage = new ChechoutPage(driver);
    }

    @Test
    public void testCompletePurchaseFlow() {
        loginPage.login("standard_user", "secret_sauce");
        productsPage.addFirstProductToCart();
        productsPage.goToCart();
        cartPage.clickCheckout();
        checkoutPage.enterFirstName("John");
        checkoutPage.enterLastName("Doe");
        checkoutPage.enterPostalCode("12345");
        checkoutPage.clickContinue();
        checkoutPage.clickFinish();
        Assert.assertEquals(checkoutPage.getSuccessMessage(), "THANK YOU FOR YOUR ORDER");
    }

    @AfterMethod
    public void teardown() {
        DriverManager.quitDriver();
    }
}
