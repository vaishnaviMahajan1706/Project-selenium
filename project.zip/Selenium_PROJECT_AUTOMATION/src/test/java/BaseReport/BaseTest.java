package BaseReport;

public class BaseTest {

}
