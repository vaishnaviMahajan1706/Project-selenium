package UiTests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import Pages.LoginPage;
import Utils.BaseTestWithReport;
import Utils.ScreenshotUtil;
import com.aventstack.extentreports.Status;
import static org.testng.Assert.assertEquals;

public class LoginTestWithReport extends BaseTestWithReport {

    WebDriver driver;
    LoginPage loginPage;

    @BeforeMethod
    public void setup() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.saucedemo.com/");
        loginPage = new LoginPage(driver);
        test = extent.createTest("Login Test"); 
    }

    @Test
    public void standardUserLoginTest() {
        try {
            loginPage.login("standard_user", "secret_sauce");
            assertEquals(driver.getCurrentUrl(), "https://www.saucedemo.com/inventory.html");
            test.log(Status.PASS, "Standard user login successful");
        } catch (Exception e) {
            String screenshot = ScreenshotUtil.captureScreenshot(driver, "LoginFail");
            test.addScreenCaptureFromPath(screenshot);
            test.log(Status.FAIL, "Login test failed: " + e.getMessage());
        }
    }

    @AfterMethod
    public void teardown() {
        driver.quit();
    }
}
