package apiTests;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;
import Utils.BaseTestWithReport;

import com.aventstack.extentreports.Status;

import static io.restassured.RestAssured.*;

public class UpdateUserWithReport extends BaseTestWithReport {

    @Test
    public void updateUserTest() {
        test = extent.createTest("PUT Update User API Test");

        try {
            Response response = given()
                    .baseUri("https://reqres.in/api")
                    .contentType(ContentType.JSON)
                    .body("{\"name\": \"Vaishnavi\", \"job\": \"Senior QA\"}")
                    .when().put("/users/2")
                    .then().statusCode(200)
                    .extract().response();

            test.log(Status.INFO, "API Response: " + response.asPrettyString());
            Assert.assertEquals(response.jsonPath().getString("name"), "Vaishnavi");
            Assert.assertEquals(response.jsonPath().getString("job"), "Senior QA");
            test.log(Status.PASS, "Update User API passed");

        } catch (Exception e) {
            test.log(Status.FAIL, "Update User API failed: " + e.getMessage());
        }
    }
}
