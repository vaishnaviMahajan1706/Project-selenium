package apiTests;

import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;
import Utils.BaseTestWithReport;

import com.aventstack.extentreports.Status;

import static io.restassured.RestAssured.*;

public class GetUsersWithReport extends BaseTestWithReport {

    @Test
    public void getUsersTest() {
        test = extent.createTest("GET Users API Test");

        try {
            Response response = given()
                    .baseUri("https://reqres.in/api")
                    .when().get("/users?page=2")
                    .then().statusCode(200)
                    .extract().response();

            test.log(Status.INFO, "API Response: " + response.asPrettyString());
            String email = response.jsonPath().getString("data[0].email");
            Assert.assertEquals(email, "michael.lawson@reqres.in", "First user email mismatch!");
            test.log(Status.PASS, "GET Users API passed");

        } catch (Exception e) {
            test.log(Status.FAIL, "GET Users API failed: " + e.getMessage());
        }
    }
}
