package apiTests;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;
import Utils.BaseTestWithReport;

import com.aventstack.extentreports.Status;

import static io.restassured.RestAssured.*;

public class CreateUserWithReport extends BaseTestWithReport {

    @Test
    public void createUserTest() {
        test = extent.createTest("POST Create User API Test");

        try {
            Response response = given()
                    .baseUri("https://reqres.in/api")
                    .contentType(ContentType.JSON)
                    .body("{\"name\": \"Vaishnavi\", \"job\": \"QA Engineer\"}")
                    .when().post("/users")
                    .then().statusCode(201)
                    .extract().response();

            test.log(Status.INFO, "API Response: " + response.asPrettyString());
            Assert.assertEquals(response.jsonPath().getString("name"), "Vaishnavi");
            Assert.assertEquals(response.jsonPath().getString("job"), "QA Engineer");
            test.log(Status.PASS, "Create User API passed");

        } catch (Exception e) {
            test.log(Status.FAIL, "Create User API failed: " + e.getMessage());
        }
    }
}
