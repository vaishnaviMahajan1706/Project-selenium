package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ProductPage {

    private WebDriver driver;
    private By firstProductAddToCart = By.cssSelector(".inventory_item button");
    private By cartIcon = By.className("shopping_cart_link");

    public ProductPage(WebDriver driver) {
        this.driver = driver;
    }

    public void addFirstProductToCart() {
        driver.findElement(firstProductAddToCart).click();
    }

    public void goToCart() {
        driver.findElement(cartIcon).click();
    }
}
