package stepDefinitions;





import io.cucumber.java.en.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import Pages.LoginPage;
import Pages.ProductPage;
import Pages.Cartpage;
import Utils.DriverManager;

public class AddToCartSteps {

    WebDriver driver = DriverManager.getDriver();
    LoginPage loginPage = new LoginPage(driver);
    ProductPage productsPage = new ProductPage(driver);
    Cartpage cartPage = new Cartpage(driver);

    @Given("User is on SauceDemo login page")
    public void openLoginPage() {
        driver.get("https://www.saucedemo.com/");
    }

    @When("User logs in with valid credentials")
    public void login() {
        loginPage.login("standard_user", "secret_sauce");
    }

    @When("User adds the first product to cart")
    public void addFirstProduct() {
        productsPage.addFirstProductToCart();
    }

    @Then("User should see the item in the cart")
    public void verifyCart() {
        productsPage.goToCart();
        int cartCount = driver.findElements(By.className("cart_item")).size();
        Assert.assertEquals(cartCount, 1, "Cart should have 1 item");
        DriverManager.quitDriver();
    }
}
